<template>
  <Heading />
  <div class="max-w-7xl mx-auto flex flex-wrap items-center justify-between">
    <div class="grid grid-rows-12 w-full">
      <Hero />
      <Usp />
      <Market />
      <Live />
      <Platform />
      <AccountType />
      <CtaTrade />
    </div>
  </div>
  <Footing />
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import AccountType from '@/components/AccountType.vue'
import CtaTrade from '@/components/CtaTrade.vue'
import Heading from '@/components/Heading.vue'
import Footing from '@/components/Footing.vue'
import Hero from '@/components/Hero.vue'
import Market from '@/components/Market.vue'
import Live from '@/components/Live.vue'
import Platform from '@/components/Platform.vue'
import Usp from '@/components/Usp.vue'

export default defineComponent({
  name: 'App',
  components: {
    Heading,
    Footing,
    AccountType,
    CtaTrade,
    Market,
    Live,
    Platform,
    Hero,
    Usp
  }
})
</script>

<style scoped>
.mainpage {
  background-color: #fafafafa;
  display: flex;
  flex-direction: row;
  justify-content: center;
  width: 100%;
}

.mainpage .div-9 {
  background-color: #fafafafa;
  height: 4915px;
  position: relative;
  width: 1512px;
}
</style>
