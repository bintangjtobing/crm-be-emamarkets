<template>
  <div class="grid row-span-2 grid-cols-12">
    <img
      class="w-52 pt-8 col-span-2"
      :alt="$t('footer.links.logo')"
      src="@/assets/img/logo-02-1.svg"
    />
    <img
      class="w-44 pt-8 ml-8 col-start-11 col-span-2"
      :alt="$t('footer.links.group')"
      src="@/assets/img/group-139.png"
    />
  </div>
  <div :class="`sitemap w-full p-4 grid row-span-4 grid-cols-6 gap-1`">
    <div v-for="(sitemap, sk, si) in groups" :key="`sitemap-${si}`">
      <span class="text-wrapper pt-3">{{ $t(`footer.links.${sk}`) }}</span
      ><br /><br />
      <a
        v-for="(link, lk, li) in sitemap"
        :href="`${link || 'javascript:void(0)'}`"
        :key="`link-${li}`"
        :class="`text-wrapper-link pt-3`"
      >
        {{ $t(`footer.links.${lk}`) }}<br
      /></a>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import sitemaps from '@/assets/sitemaps.json'
const group: any = sitemaps

export default defineComponent({
  name: 'Sitemap',
  data() {
    return {
      groups: group
    }
  }
})
</script>

<style>
.sitemap {
  color: #ffffff;
  font-family: 'Poppins', Helvetica;
  letter-spacing: 0;
}

.sitemap .text-wrapper {
  font-size: 20px;
  font-weight: 500;
  line-height: 22.7px;
  white-space: nowrap;
}

.sitemap .text-wrapper-link {
  font-size: 14px;
  font-weight: 400;
  line-height: 15.9px;
}
</style>
