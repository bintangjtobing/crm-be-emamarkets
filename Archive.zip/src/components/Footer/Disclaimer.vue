<template>
  <div class="disclaimer w-full p-4 grid row-start-8 row-span-5 grid-cols-2 gap-24">
    <!-- <img class="vector" alt="Vector" src="@/assets/img/vector-3.svg" /> -->
    <p class="left-disclaimer" v-html="$t('footer.disclaimer.left')"></p>
    <p class="right-disclaimer" v-html="$t('footer.disclaimer.right')"></p>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'Disclaimer'
})
</script>

<style>
.disclaimer {
  color: #8a8a8a;
  /* font-family: 'Poppins', Helvetica; */
  font-size: 14px;
  font-weight: 400;
  left: 1px;
  letter-spacing: 0;
  line-height: 15.9px;
  text-align: justify;
  white-space: pre-line;
}
</style>
