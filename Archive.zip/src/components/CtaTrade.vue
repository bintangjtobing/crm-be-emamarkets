<template>
  <section id="trade" class="trade row-start-12 grid grid-rows-4 gap-0">
    <div
      class="row-start-2 row-span-2 overflow-visible rounded-xl w-full bg-gradient-to-br from-blue-700 to-blue-950 grid grid-cols-5 gap-0 place-items-center"
    >
      <img class="overflow-visible light -mt-20" alt="Light" src="@/assets/img/mask-group-1.png" />
      <span
        class="trade-title col-span-2 text-left inline-flex items-start -ml-36"
        v-html="$t(`home.trade.title`, { break: '<br />' })"
      ></span>
      <button
        class="col-start-5 bg-white text-blue-950 text-lg font-black py-2 px-6 rounded-full font-poppins"
      >
        {{ $t(`home.trade.action`) }}
      </button>
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'CtaTrade'
})
</script>

<style>
.CTA-trade {
  height: 224px;
  left: 104px;
  position: absolute;
  top: 3687px;
  width: 1306px;
}

.CTA-trade .overlap-14 {
  height: 224px;
  position: relative;
  width: 1304px;
}

.CTA-trade .rectangle-5 {
  background: radial-gradient(50% 50% at 50% 50%, rgb(52, 107, 227) 0%, rgb(11, 23, 69) 100%);
  border-radius: 15px;
  height: 167px;
  left: 0;
  position: absolute;
  top: 57px;
  width: 1304px;
}

.CTA-trade .text-wrapper-93 {
  color: #ffffff;
  font-family: 'Poppins', Helvetica;
  font-size: 32px;
  font-weight: 500;
  left: 247px;
  letter-spacing: 0;
  line-height: 36.4px;
  position: absolute;
  top: 105px;
  width: 437px;
}

.CTA-trade .overlap-group-wrapper-3 {
  height: 52px;
  left: 1033px;
  position: absolute;
  top: 115px;
  width: 218px;
}

.CTA-trade .overlap-group-12 {
  background-color: #ffffff;
  border-radius: 100px;
  height: 52px;
  position: relative;
  width: 216px;
}

.CTA-trade .text-wrapper-94 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  height: 26px;
  left: 41px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 13px;
  width: 139px;
}

.CTA-trade .mask-group {
  height: 224px;
  left: 1px;
  position: absolute;
  top: 0;
  width: 239px;
}
/* 
.CTA-trade .overlap-group-12 {
  background-color: #ffffff;
  border-radius: 100px;
  height: 52px;
  position: relative;
  width: 216px;
}

.CTA-trade .text-wrapper-94 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  height: 26px;
  left: 41px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 13px;
  width: 139px;
} */

.trade-title {
  color: #ffffff;
  font-family: 'Poppins', Helvetica;
  font-size: 32px;
  font-weight: 500;
  /* left: 247px; */
  letter-spacing: 0;
  line-height: 36.4px;
  /* position: absolute;
  top: 105px;
  width: 437px; */
}
</style>
