<template>
  <img class="header" alt="Header" src="@/assets/img/header.png" />
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'HeaderView',
  components: {}
})
</script>

<style>
.mainpage .header {
  height: 86px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1512px;
}
</style>
