<template>
  <div class="group-4">
    <div class="overlap-10">
      <img class="group-53" alt="Group" src="@/assets/img/group-84.png" />
      <div class="group-54">
        <div class="group-55">
          <img class="vector-5" alt="Vector" src="@/assets/img/vector-1-3.svg" />
          <div class="text-wrapper-73">NVIDIA</div>
          <div class="overlap-11">
            <div class="text-wrapper-74">252.560</div>
          </div>
          <div class="text-wrapper-75">+3.146</div>
          <div class="group-56">
            <div class="overlap-group-10">
              <div class="text-wrapper-76">+2.223</div>
              <img class="polygon-4" alt="Polygon" src="@/assets/img/polygon-1-4.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'GroupFour'
})
</script>

<style>
.group-4 {
  height: 43px;
  left: 18px;
  position: absolute;
  top: 230px;
  width: 574px;
}

.group-4 .overlap-10 {
  height: 44px;
  position: relative;
}

.group-4 .group-53 {
  height: 44px;
  left: 9px;
  position: absolute;
  top: 0;
  width: 44px;
}

.group-4 .group-54 {
  height: 38px;
  left: 0;
  position: absolute;
  top: 5px;
  width: 574px;
}

.group-4 .group-55 {
  height: 38px;
  position: relative;
  width: 580px;
}

.group-4 .vector-5 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 38px;
  width: 574px;
}

.group-4 .text-wrapper-73 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 62px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.group-4 .overlap-11 {
  background-color: #3b7e23;
  height: 24px;
  left: 185px;
  position: absolute;
  top: 0;
  width: 78px;
}

.group-4 .text-wrapper-74 {
  color: #ffffff;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.group-4 .text-wrapper-75 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 337px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.group-4 .group-56 {
  height: 17px;
  left: 492px;
  position: absolute;
  top: 4px;
  width: 80px;
}

.group-4 .overlap-group-10 {
  height: 17px;
  position: relative;
  width: 78px;
}

.group-4 .text-wrapper-76 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.group-4 .polygon-4 {
  height: 8px;
  left: 3px;
  position: absolute;
  top: 3px;
  width: 10px;
}
</style>
