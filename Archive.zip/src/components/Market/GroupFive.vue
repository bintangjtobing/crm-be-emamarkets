<template>
  <div class="group-5">
    <div class="overlap-12">
      <div class="vector-wrapper">
        <img class="vector-6" alt="Vector" src="@/assets/img/vector.svg" />
      </div>
      <div class="group-57">
        <div class="group-58">
          <div class="group-59">
            <img class="vector-7" alt="Vector" src="@/assets/img/vector-1-4.png" />
            <div class="text-wrapper-77">NFLX</div>
            <div class="text-wrapper-78">252.560</div>
            <div class="text-wrapper-79">+3.146</div>
            <div class="group-60">
              <div class="overlap-group-11">
                <div class="text-wrapper-80">+2.223</div>
                <img class="polygon-5" alt="Polygon" src="@/assets/img/polygon-1-4.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'GroupFive'
})
</script>

<style>
.group-5 {
  height: 43px;
  left: 18px;
  position: absolute;
  top: 282px;
  width: 574px;
}

.group-5 .overlap-12 {
  height: 43px;
  position: relative;
}

.group-5 .vector-wrapper {
  background-color: #ffffff;
  border-radius: 18px;
  box-shadow: 0px 4px 4px #00000026;
  height: 36px;
  left: 13px;
  position: absolute;
  top: 0;
  width: 36px;
}

.group-5 .vector-6 {
  height: 7px;
  left: 5px;
  position: absolute;
  top: 15px;
  width: 25px;
}

.group-5 .group-57 {
  height: 34px;
  left: 0;
  position: absolute;
  top: 9px;
  width: 574px;
}

.group-5 .group-58 {
  height: 34px;
}

.group-5 .group-59 {
  height: 34px;
  position: relative;
  width: 580px;
}

.group-5 .vector-7 {
  height: 1px;
  left: 831px;
  position: absolute;
  top: 1680px;
  width: 574px;
}

.group-5 .text-wrapper-77 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 62px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.group-5 .text-wrapper-78 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 185px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.group-5 .text-wrapper-79 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 337px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.group-5 .group-60 {
  height: 17px;
  left: 492px;
  position: absolute;
  top: 0;
  width: 80px;
}

.group-5 .overlap-group-11 {
  height: 17px;
  position: relative;
  width: 78px;
}

.group-5 .text-wrapper-80 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.group-5 .polygon-5 {
  height: 8px;
  left: 3px;
  position: absolute;
  top: 3px;
  width: 10px;
}
</style>
