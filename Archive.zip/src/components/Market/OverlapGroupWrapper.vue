<template>
  <div class="overlap-group-wrapper">
    <div class="overlap-8">
      <div class="group-48">
        <div class="group-49" />
      </div>
      <div class="group-50">
        <div class="group-51">
          <img class="vector-4" alt="Vector" src="@/assets/img/vector-1-3.svg" />
          <div class="text-wrapper-69">META</div>
          <div class="text-wrapper-70">195.670</div>
          <div class="overlap-9">
            <div class="rectangle-3" />
            <div class="text-wrapper-71">+3.146</div>
          </div>
          <div class="group-52">
            <div class="overlap-group-9">
              <div class="text-wrapper-72">+2.223</div>
              <img class="polygon-3" alt="Polygon" src="@/assets/img/polygon-1-4.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'OverlapGroupWrapper'
})
</script>

<style>
.overlap-group-wrapper {
  height: 47px;
  left: 18px;
  position: absolute;
  top: 174px;
  width: 574px;
}

.overlap-group-wrapper .overlap-8 {
  height: 47px;
  position: relative;
}

.overlap-group-wrapper .group-48 {
  background-color: #ffffff;
  border-radius: 18px;
  box-shadow: 0px 4px 4px #00000026;
  height: 36px;
  left: 13px;
  position: absolute;
  top: 0;
  width: 36px;
}

.overlap-group-wrapper .group-49 {
  background-image: url(@/assets/img/meta-platforms-inc-logo-svg.png);
  background-position: 50% 50%;
  background-size: cover;
  height: 6px;
  left: 4px;
  position: relative;
  top: 15px;
  width: 28px;
}

.overlap-group-wrapper .group-50 {
  height: 38px;
  left: 0;
  position: absolute;
  top: 9px;
  width: 574px;
}

.overlap-group-wrapper .group-51 {
  height: 38px;
  position: relative;
  width: 580px;
}

.overlap-group-wrapper .vector-4 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 38px;
  width: 574px;
}

.overlap-group-wrapper .text-wrapper-69 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 62px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.overlap-group-wrapper .text-wrapper-70 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 185px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.overlap-group-wrapper .overlap-9 {
  height: 24px;
  left: 337px;
  position: absolute;
  top: 0;
  width: 78px;
}

.overlap-group-wrapper .rectangle-3 {
  background-color: #3b7e23;
  height: 24px;
  left: 11px;
  position: absolute;
  top: 0;
  width: 58px;
}

.overlap-group-wrapper .text-wrapper-71 {
  color: #ffffff;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.overlap-group-wrapper .group-52 {
  height: 17px;
  left: 492px;
  position: absolute;
  top: 4px;
  width: 80px;
}

.overlap-group-wrapper .overlap-group-9 {
  height: 17px;
  position: relative;
  width: 78px;
}

.overlap-group-wrapper .text-wrapper-72 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.overlap-group-wrapper .polygon-3 {
  height: 8px;
  left: 3px;
  position: absolute;
  top: 3px;
  width: 10px;
}
</style>
