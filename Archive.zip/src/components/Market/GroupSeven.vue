<template>
  <div class="group-7">
    <div class="text-wrapper-83">Stocks</div>
    <p class="text-wrapper-84">
      Choose from the hundreds of individual stocks available in US and more.
    </p>
    <GroupSix />
    <div class="CTA-trade-6">
      <div class="overlap-13">
        <div class="text-wrapper-85">START TRADING</div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import GroupSix from './GroupSix.vue'

export default defineComponent({
  name: 'GroupSeven',
  components: {
    GroupSix
  }
})
</script>

<style>
.group-7 {
  height: 377px;
  /* left: 0; */
  position: absolute;
  /* top: 344px; */
  width: 1279px;
}

.group-7 .text-wrapper-83 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 40px;
  font-weight: 500;
  left: 673px;
  letter-spacing: 0;
  line-height: 45.5px;
  position: absolute;
  top: 50px;
  width: 602px;
}

.group-7 .text-wrapper-84 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  left: 673px;
  letter-spacing: 0;
  line-height: 31.2px;
  position: absolute;
  top: 121px;
  width: 602px;
}

.group-7 .CTA-trade-6 {
  height: 52px;
  left: 673px;
  position: absolute;
  top: 242px;
  width: 218px;
}

.group-7 .overlap-13 {
  background: radial-gradient(50% 50% at 50% 50%, rgb(52, 107, 227) 0%, rgb(11, 23, 69) 100%);
  border-radius: 100px;
  height: 52px;
  position: relative;
  width: 216px;
}

.group-7 .text-wrapper-85 {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  height: 26px;
  left: 41px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 13px;
  width: 139px;
}
</style>
