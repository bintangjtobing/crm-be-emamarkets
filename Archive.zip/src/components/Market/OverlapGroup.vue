<template>
  <div class="overlap-group">
    <Overlap />
    <GroupThree />
    <OverlapWrapper />
    <OverlapGroupWrapper />
    <GroupFour />
    <GroupFive />
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import Overlap from './Overlap.vue'
import GroupThree from './GroupThree.vue'
import OverlapWrapper from './OverlapWrapper.vue'
import OverlapGroupWrapper from './OverlapGroupWrapper.vue'
import GroupFour from './GroupFour.vue'
import GroupFive from './GroupFive.vue'

export default defineComponent({
  name: 'OverlapGroup',
  components: {
    Overlap,
    GroupThree,
    OverlapWrapper,
    OverlapGroupWrapper,
    GroupFour,
    GroupFive
  }
})
</script>

<style>
.overlap-group {
  background-color: #ffffff;
  border-radius: 15px;
  box-shadow: 0px 10px 14px #00000026;
  height: 343px;
  left: 0;
  position: absolute;
  top: 0;
  width: 610px;
}
</style>
