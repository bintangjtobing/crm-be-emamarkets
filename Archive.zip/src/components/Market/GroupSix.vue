<template>
  <div class="group-6">
    <p class="p">Real time (Indicative) Updated:10:38:31 GMT+8</p>
    <OverlapGroup />
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import OverlapGroup from './OverlapGroup.vue'

export default defineComponent({
  name: 'GroupSix',
  components: {
    OverlapGroup
  }
})
</script>

<style>
.group-6 {
  height: 377px;
  /* left: 0; */
  position: absolute;
  /* top: 0; */
  width: 627px;
}

.group-6 .p {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 12px;
  font-weight: 400;
  left: 15px;
  letter-spacing: 0;
  line-height: 13.6px;
  position: absolute;
  top: 363px;
  width: 602px;
}
</style>
