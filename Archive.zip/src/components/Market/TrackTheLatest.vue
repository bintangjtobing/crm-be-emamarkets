<template>
  <p class="track-the-latest">
    <span class="text-wrapper-81">Track the latest market movements in </span>
    <span class="text-wrapper-82">real-time.</span>
  </p>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'TrackTheLatest'
})
</script>

<style>
.track-the-latest {
  color: transparent;
  font-family: 'Poppins', Helvetica;
  font-size: 50px;
  font-weight: 500;
  left: 314px;
  letter-spacing: 0;
  line-height: 56.8px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 647px;
}

.track-the-latest .text-wrapper-81 {
  color: #000000;
}

.track-the-latest .text-wrapper-82 {
  color: #043286;
}
</style>
