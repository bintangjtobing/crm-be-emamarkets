<template>
  <div class="overlap-wrapper">
    <div class="overlap-6">
      <img class="group-46" alt="Group" src="@/assets/img/group-82.png" />
      <div class="group-47">
        <img class="vector-3" alt="Vector" src="@/assets/img/vector-1-3.svg" />
        <div class="text-wrapper-65">TSLA</div>
        <div class="text-wrapper-66">195.670</div>
        <div class="overlap-7">
          <div class="rectangle-2" />
          <div class="text-wrapper-67">-2.920</div>
        </div>
        <div class="overlap-group-8">
          <div class="text-wrapper-68">-2.920</div>
          <img class="polygon-2" alt="Polygon" src="@/assets/img/polygon-1-1.svg" />
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'OverlapWrapper'
})
</script>

<style>
.overlap-wrapper {
  height: 47px;
  left: 18px;
  position: absolute;
  top: 118px;
  width: 574px;
}

.overlap-wrapper .overlap-6 {
  height: 47px;
  position: relative;
  width: 582px;
}

.overlap-wrapper .group-46 {
  height: 44px;
  left: 9px;
  position: absolute;
  top: 0;
  width: 44px;
}

.overlap-wrapper .group-47 {
  height: 38px;
  left: 0;
  position: absolute;
  top: 9px;
  width: 582px;
}

.overlap-wrapper .vector-3 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 38px;
  width: 574px;
}

.overlap-wrapper .text-wrapper-65 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 62px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.overlap-wrapper .text-wrapper-66 {
  color: #9f2226;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 185px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.overlap-wrapper .overlap-7 {
  height: 24px;
  left: 337px;
  position: absolute;
  top: 0;
  width: 78px;
}

.overlap-wrapper .rectangle-2 {
  background-color: #9f2227;
  height: 24px;
  left: 11px;
  position: absolute;
  top: 0;
  width: 58px;
}

.overlap-wrapper .text-wrapper-67 {
  color: #ffffff;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 4px;
  width: 78px;
}

.overlap-wrapper .overlap-group-8 {
  height: 17px;
  left: 492px;
  position: absolute;
  top: 4px;
  width: 78px;
}

.overlap-wrapper .text-wrapper-68 {
  color: #9f2227;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.overlap-wrapper .polygon-2 {
  height: 8px;
  left: 3px;
  position: absolute;
  top: 6px;
  width: 10px;
}
</style>
