<template>
  <div class="group-8">
    <div class="group-61">
      <div class="rectangle-4" />
      <div class="group-62">
        <div class="group-63">
          <div class="text-wrapper-86">Crypto</div>
          <div class="text-wrapper-87">Commodities</div>
          <div class="text-wrapper-88">Energy</div>
          <div class="text-wrapper-89">Stocks</div>
          <div class="text-wrapper-90">Indices</div>
          <div class="text-wrapper-91 border-b-4">Metal</div>
          <div class="text-wrapper-92">Currencies</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'GroupEight'
})
</script>

<style>
.group-8 {
  height: 48px;
  /* left: 137px; */
  position: absolute;
  /* top: 259px; */
  width: 1001px;
}

.group-8 .group-61 {
  height: 48px;
  position: relative;
}

.group-8 .rectangle-4 {
  background-color: #043286;
  height: 6px;
  left: 287px;
  position: absolute;
  top: 42px;
  width: 101px;
}

.group-8 .group-62 {
  height: 28px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1001px;
}

.group-8 .group-63 {
  height: 28px;
  position: relative;
  width: 1015px;
}

.group-8 .text-wrapper-86 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  height: 28px;
  left: 902px;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 99px;
}

.group-8 .text-wrapper-87 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  height: 28px;
  left: 564px;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 0;
  white-space: nowrap;
}

.group-8 .text-wrapper-88 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  height: 28px;
  left: 770px;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 96px;
}

.group-8 .text-wrapper-89 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 500;
  height: 28px;
  left: 286px;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 101px;
}

.group-8 .text-wrapper-90 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  height: 28px;
  left: 423px;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 105px;
}

.group-8 .text-wrapper-91 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  height: 28px;
  left: 172px;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.group-8 .text-wrapper-92 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  height: 28px;
  left: 0;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 0;
  white-space: nowrap;
}
.active {
  color: #043286;
}
</style>
