<template>
  <div class="group-3">
    <img class="vector-2" alt="Vector" src="@/assets/img/vector-1-3.svg" />
    <img class="group-45" alt="Group" src="@/assets/img/group-83.png" />
    <div class="text-wrapper-61">AAPL</div>
    <div class="text-wrapper-62">195.670</div>
    <div class="text-wrapper-63">-2.920</div>
    <div class="overlap-group-7">
      <div class="text-wrapper-64">-2.920</div>
      <img class="polygon" alt="Polygon" src="@/assets/img/polygon-1.svg" />
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'GroupThree'
})
</script>

<style>
.group-3 {
  height: 48px;
  left: 18px;
  position: absolute;
  top: 61px;
  width: 582px;
}

.group-3 .vector-2 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 48px;
  width: 574px;
}

.group-3 .group-45 {
  height: 44px;
  left: 9px;
  position: absolute;
  top: 0;
  width: 44px;
}

.group-3 .text-wrapper-61 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 62px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 14px;
  width: 78px;
}

.group-3 .text-wrapper-62 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 185px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 14px;
  width: 78px;
}

.group-3 .text-wrapper-63 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 337px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 14px;
  width: 78px;
}

.group-3 .overlap-group-7 {
  height: 17px;
  left: 492px;
  position: absolute;
  top: 14px;
  width: 78px;
}

.group-3 .text-wrapper-64 {
  color: #3b7e23;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 78px;
}

.group-3 .polygon {
  height: 8px;
  left: 3px;
  position: absolute;
  top: 3px;
  width: 10px;
}
</style>
