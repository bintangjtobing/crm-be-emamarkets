<template>
  <div class="overlap">
    <div class="text-wrapper-57">%</div>
    <div class="rectangle" />
    <div class="text-wrapper-58">Symbol</div>
    <div class="text-wrapper-59">Buy</div>
    <div class="text-wrapper-60">Change</div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'Overlap'
})
</script>

<style>
.overlap {
  border-radius: 15px 15px 0px 0px;
  height: 50px;
  left: 0;
  position: absolute;
  top: 0;
  width: 610px;
}

.overlap .text-wrapper-57 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 496px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 18px;
  width: 106px;
}

.overlap .rectangle {
  background-color: #04328633;
  border-radius: 15px 15px 0px 0px;
  height: 50px;
  left: 0;
  position: absolute;
  top: 0;
  width: 610px;
}

.overlap .text-wrapper-58 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 31px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 18px;
  width: 106px;
}

.overlap .text-wrapper-59 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 186px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 18px;
  width: 106px;
}

.overlap .text-wrapper-60 {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 341px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 18px;
  width: 106px;
}
</style>
