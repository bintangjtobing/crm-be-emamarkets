<template>
  <section id="hero" class="hero row-span-3 grid grid-rows-11 gap-4 place-items-center">
    <div
      class="hero-title row-start-2"
      v-html="
        $t(`home.hero.title`, {
          'black-start': '<span class=text-black>',
          'black-end': '</span>'
        })
      "
    ></div>
    <div class="hero-subtitle row-start-3">
      {{ $t(`home.hero.subtitle`) }}
    </div>
    <div class="row-start-4">
      <button
        class="bg-gradient-to-br from-blue-500 to-blue-950 hover:from-blue-950 hover:to-blue-500 delay-300 text-white text-lg py-2 px-6 rounded-full font-poppins"
      >
        {{ $t(`home.hero.action`) }}
      </button>
    </div>
    <div class="device w-full row-start-5 row-span-7 justify-center">
      <img class="dark mx-auto" alt="Dark" src="@/assets/img/dark-05-1.png" />
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Hero'
})
</script>

<style>
.hero .device {
  /* height: 901px; */
  /* left: 1px; */
  /* position: absolute; */
  /* top: 152px; */
  /* width: 1510px; */
  background-image: url(@/assets/img/mask-group-3.png);
}

.hero .dark {
  /* height: 552px; */
  /* left: 452px; */
  object-fit: cover;
  /* position: absolute; */
  /* top: 298px; */
}

.hero .hero-title {
  /* color: transparent; */
  font-size: 50px;
  font-weight: 500;
  /* left: 83px; */
  letter-spacing: 0;
  line-height: 56.8px;

  color: #043286;
  /* position: absolute; */
  /* top: 0; */
  /* width: 707px; */
}

.hero .hero-subtitle {
  color: #424245;
  font-size: 25px;
  font-weight: 300;
  letter-spacing: 0;
  line-height: 34.3px;
  text-align: center;
  /* position: absolute;
  top: 78px; */
  width: 854px;
}
</style>
