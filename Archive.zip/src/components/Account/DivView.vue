<template>
  <div class="div">
    <div class="group-18">
      <div class="overlap-3">
        <div class="text-wrapper-35">Standard Account</div>
        <div class="text-wrapper-36">Starters</div>
        <div class="group-19">
          <div class="group-20">
            <div class="text-wrapper-37">Up to 1000:1 leverage</div>
            <img class="group-21" alt="Group" src="@/assets/img/group-4.png" />
          </div>
          <div class="group-22">
            <div class="text-wrapper-38">Spreads from 1.2</div>
            <img class="group-23" alt="Group" src="@/assets/img/group-5.png" />
          </div>
          <div class="group-24">
            <div class="text-wrapper-39">No min. deposit</div>
            <img class="group-25" alt="Group" src="@/assets/img/group-6.png" />
          </div>
          <div class="group-26">
            <div class="text-wrapper-40">No commission</div>
            <img class="group-25" alt="Group" src="@/assets/img/group-7.png" />
          </div>
        </div>
        <div class="CTA-trade-3">
          <div class="overlap-group-4">
            <div class="text-wrapper-41">MORE INFO</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'DivView'
})
</script>

<style>
.div {
  height: 416px;
  left: 328px;
  position: absolute;
  top: 0;
  width: 302px;
}

.div .group-18 {
  height: 416px;
  width: 306px;
}

.div .overlap-3 {
  background-color: #ffffff;
  border-radius: 15px;
  box-shadow: 0px 8px 8px #00000026;
  height: 416px;
  position: relative;
  width: 302px;
}

.div .text-wrapper-35 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 20px;
  font-weight: 500;
  left: 56px;
  letter-spacing: 0;
  line-height: 22.7px;
  position: absolute;
  text-align: center;
  top: 35px;
  white-space: nowrap;
  width: 191px;
}

.div .text-wrapper-36 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 117px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 63px;
  white-space: nowrap;
  width: 67px;
}

.div .group-19 {
  height: 166px;
  left: 39px;
  position: absolute;
  top: 116px;
  width: 225px;
}

.div .group-20 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 0;
  width: 227px;
}

.div .text-wrapper-37 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 181px;
}

.div .group-21 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 6px;
  width: 22px;
}

.div .group-22 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 51px;
  width: 186px;
}

.div .text-wrapper-38 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 140px;
}

.div .group-23 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 2px;
  width: 22px;
}

.div .group-24 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 100px;
  width: 179px;
}

.div .text-wrapper-39 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 2px;
  white-space: nowrap;
  width: 133px;
}

.div .group-25 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 0;
  width: 22px;
}

.div .group-26 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 147px;
  width: 179px;
}

.div .text-wrapper-40 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 133px;
}

.div .CTA-trade-3 {
  height: 59px;
  left: 28px;
  position: absolute;
  top: 342px;
  width: 247px;
}

.div .overlap-group-4 {
  background: radial-gradient(50% 50% at 50% 50%, rgb(52, 107, 227) 0%, rgb(11, 23, 69) 100%);
  border-radius: 100px;
  height: 59px;
  position: relative;
  width: 245px;
}

.div .text-wrapper-41 {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  height: 29px;
  left: 47px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 15px;
  width: 158px;
}
</style>
