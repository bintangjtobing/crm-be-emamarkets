<template>
  <div class="section-component-node">
    <div class="group-27">
      <div class="overlap-4">
        <div class="text-wrapper-42">Professional Account</div>
        <div class="text-wrapper-43">Advanced</div>
        <div class="group-28">
          <div class="group-29">
            <div class="text-wrapper-44">Up to 1000:1 leverage</div>
            <img class="group-30" alt="Group" src="@/assets/img/group-8.png" />
          </div>
          <div class="group-31">
            <div class="text-wrapper-45">Spreads from 1.2</div>
            <img class="group-32" alt="Group" src="@/assets/img/group-9.png" />
          </div>
          <div class="group-33">
            <div class="text-wrapper-46">No min. deposit</div>
            <img class="group-34" alt="Group" src="@/assets/img/group-10.png" />
          </div>
          <div class="group-35">
            <div class="text-wrapper-47">No commission</div>
            <img class="group-34" alt="Group" src="@/assets/img/group-11.png" />
          </div>
        </div>
        <div class="CTA-trade-4">
          <div class="overlap-group-5">
            <div class="text-wrapper-48">MORE INFO</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'SectionComponentNode'
})
</script>

<style>
.section-component-node {
  height: 416px;
  left: 656px;
  position: absolute;
  top: 0;
  width: 302px;
}

.section-component-node .group-27 {
  height: 416px;
  width: 306px;
}

.section-component-node .overlap-4 {
  background-color: #ffffff;
  border-radius: 15px;
  box-shadow: 0px 8px 8px #00000026;
  height: 416px;
  position: relative;
  width: 302px;
}

.section-component-node .text-wrapper-42 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 20px;
  font-weight: 500;
  left: 38px;
  letter-spacing: 0;
  line-height: 22.7px;
  position: absolute;
  text-align: center;
  top: 35px;
  white-space: nowrap;
  width: 225px;
}

.section-component-node .text-wrapper-43 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 112px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 63px;
  white-space: nowrap;
}

.section-component-node .group-28 {
  height: 166px;
  left: 39px;
  position: absolute;
  top: 116px;
  width: 225px;
}

.section-component-node .group-29 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 0;
  width: 227px;
}

.section-component-node .text-wrapper-44 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 181px;
}

.section-component-node .group-30 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 6px;
  width: 22px;
}

.section-component-node .group-31 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 51px;
  width: 186px;
}

.section-component-node .text-wrapper-45 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 140px;
}

.section-component-node .group-32 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 2px;
  width: 22px;
}

.section-component-node .group-33 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 100px;
  width: 179px;
}

.section-component-node .text-wrapper-46 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 2px;
  white-space: nowrap;
  width: 133px;
}

.section-component-node .group-34 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 0;
  width: 22px;
}

.section-component-node .group-35 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 147px;
  width: 179px;
}

.section-component-node .text-wrapper-47 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 133px;
}

.section-component-node .CTA-trade-4 {
  height: 59px;
  left: 28px;
  position: absolute;
  top: 342px;
  width: 247px;
}

.section-component-node .overlap-group-5 {
  background: radial-gradient(50% 50% at 50% 50%, rgb(52, 107, 227) 0%, rgb(11, 23, 69) 100%);
  border-radius: 100px;
  height: 59px;
  position: relative;
  width: 245px;
}

.section-component-node .text-wrapper-48 {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  height: 29px;
  left: 47px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 15px;
  width: 158px;
}
</style>
