<template>
  <div class="group-2">
    <DivWrapper />
    <DivView />
    <SectionComponentNode />
    <GroupOne />
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import DivView from './DivView.vue'
import DivWrapper from './DivWrapper.vue'
import GroupOne from './GroupOne.vue'
import SectionComponentNode from './SectionComponentNode.vue'

export default defineComponent({
  name: 'GroupTwo',
  components: {
    DivView,
    DivWrapper,
    GroupOne,
    SectionComponentNode
  }
})
</script>

<style>
.group-2 {
  height: 416px;
  left: 0;
  position: absolute;
  top: 262px;
  width: 1287px;
}
</style>
