<template>
  <p class="maximize-your">
    <span class="span">Maximize </span>
    <span class="text-wrapper-56">
      your benefits <br />
      with the
    </span>
    <span class="span"> right account.</span>
  </p>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'MaximizeYour'
})
</script>

<style>
.maximize-your {
  color: transparent;
  font-family: 'Poppins', Helvetica;
  font-size: 50px;
  font-weight: 500;
  left: 357px;
  letter-spacing: 0;
  line-height: 56.8px;
  position: absolute;
  text-align: center;
  top: 0;
}

.maximize-your .span {
  color: #043286;
}

.maximize-your .text-wrapper-56 {
  color: #000000;
}
</style>
