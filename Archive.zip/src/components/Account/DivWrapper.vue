<template>
  <div class="div-wrapper">
    <div class="group-9">
      <div class="overlap-2">
        <div class="text-wrapper-28">Micro Account</div>
        <div class="text-wrapper-29">Starters</div>
        <div class="group-10">
          <div class="group-11">
            <div class="text-wrapper-30">Up to 1000:1 leverage</div>
            <img class="group-12" alt="Group" src="@/assets/img/group-12.png" />
          </div>
          <div class="group-13">
            <div class="text-wrapper-31">Spreads from 1.2</div>
            <img class="group-14" alt="Group" src="@/assets/img/group-13.png" />
          </div>
          <div class="group-15">
            <div class="text-wrapper-32">No min. deposit</div>
            <img class="group-16" alt="Group" src="@/assets/img/group-14.png" />
          </div>
          <div class="group-17">
            <div class="text-wrapper-33">No commission</div>
            <img class="group-16" alt="Group" src="@/assets/img/group-15.png" />
          </div>
        </div>
        <div class="CTA-trade-2">
          <div class="overlap-group-3">
            <div class="text-wrapper-34">MORE INFO</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'DivWrapper'
})
</script>

<style>
.div-wrapper {
  height: 416px;
  left: 0;
  position: absolute;
  top: 0;
  width: 302px;
}

.div-wrapper .group-9 {
  height: 416px;
  width: 306px;
}

.div-wrapper .overlap-2 {
  background-color: #ffffff;
  border-radius: 15px;
  box-shadow: 0px 8px 8px #00000026;
  height: 416px;
  position: relative;
  width: 302px;
}

.div-wrapper .text-wrapper-28 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 20px;
  font-weight: 500;
  left: 69px;
  letter-spacing: 0;
  line-height: 22.7px;
  position: absolute;
  text-align: center;
  top: 35px;
  white-space: nowrap;
  width: 165px;
}

.div-wrapper .text-wrapper-29 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 117px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 63px;
  white-space: nowrap;
  width: 67px;
}

.div-wrapper .group-10 {
  height: 166px;
  left: 39px;
  position: absolute;
  top: 116px;
  width: 225px;
}

.div-wrapper .group-11 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 0;
  width: 227px;
}

.div-wrapper .text-wrapper-30 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 181px;
}

.div-wrapper .group-12 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 6px;
  width: 22px;
}

.div-wrapper .group-13 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 51px;
  width: 186px;
}

.div-wrapper .text-wrapper-31 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 140px;
}

.div-wrapper .group-14 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 2px;
  width: 22px;
}

.div-wrapper .group-15 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 100px;
  width: 179px;
}

.div-wrapper .text-wrapper-32 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 2px;
  white-space: nowrap;
  width: 133px;
}

.div-wrapper .group-16 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 0;
  width: 22px;
}

.div-wrapper .group-17 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 147px;
  width: 179px;
}

.div-wrapper .text-wrapper-33 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 133px;
}

.div-wrapper .CTA-trade-2 {
  height: 59px;
  left: 28px;
  position: absolute;
  top: 342px;
  width: 247px;
}

.div-wrapper .overlap-group-3 {
  background: radial-gradient(50% 50% at 50% 50%, rgb(52, 107, 227) 0%, rgb(11, 23, 69) 100%);
  border-radius: 100px;
  height: 59px;
  position: relative;
  width: 245px;
}

.div-wrapper .text-wrapper-34 {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  height: 29px;
  left: 47px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 15px;
  width: 158px;
}
</style>
