<template>
  <div class="group-1">
    <div class="group-36">
      <div class="overlap-5">
        <div class="text-wrapper-49">Raw Account</div>
        <div class="text-wrapper-50">Advanced</div>
        <div class="group-37">
          <div class="group-38">
            <div class="text-wrapper-51">Up to 1000:1 leverage</div>
            <img class="group-39" alt="Group" src="@/assets/img/group-12.png" />
          </div>
          <div class="group-40">
            <div class="text-wrapper-52">Spreads from 0.0</div>
            <img class="group-41" alt="Group" src="@/assets/img/group-13.png" />
          </div>
          <div class="group-42">
            <div class="text-wrapper-53">No min. deposit</div>
            <img class="group-43" alt="Group" src="@/assets/img/group-14.png" />
          </div>
          <div class="group-44">
            <div class="text-wrapper-54">$3 Per lot</div>
            <img class="group-43" alt="Group" src="@/assets/img/group-15.png" />
          </div>
        </div>
        <div class="CTA-trade-5">
          <div class="overlap-group-6">
            <div class="text-wrapper-55">MORE INFO</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'GroupOne'
})
</script>

<style>
.group-1 {
  height: 416px;
  left: 985px;
  position: absolute;
  top: 0;
  width: 302px;
}

.group-1 .group-36 {
  height: 416px;
  width: 306px;
}

.group-1 .overlap-5 {
  background-color: #ffffff;
  border-radius: 15px;
  box-shadow: 0px 8px 8px #00000026;
  height: 416px;
  position: relative;
  width: 302px;
}

.group-1 .text-wrapper-49 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 20px;
  font-weight: 500;
  left: 38px;
  letter-spacing: 0;
  line-height: 22.7px;
  position: absolute;
  text-align: center;
  top: 35px;
  white-space: nowrap;
  width: 225px;
}

.group-1 .text-wrapper-50 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 112px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  top: 63px;
  white-space: nowrap;
}

.group-1 .group-37 {
  height: 166px;
  left: 39px;
  position: absolute;
  top: 116px;
  width: 225px;
}

.group-1 .group-38 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 0;
  width: 227px;
}

.group-1 .text-wrapper-51 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 181px;
}

.group-1 .group-39 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 6px;
  width: 22px;
}

.group-1 .group-40 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 51px;
  width: 186px;
}

.group-1 .text-wrapper-52 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 140px;
}

.group-1 .group-41 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 2px;
  width: 22px;
}

.group-1 .group-42 {
  height: 21px;
  left: 0;
  position: absolute;
  top: 100px;
  width: 179px;
}

.group-1 .text-wrapper-53 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 2px;
  white-space: nowrap;
  width: 133px;
}

.group-1 .group-43 {
  height: 15px;
  left: 0;
  position: absolute;
  top: 0;
  width: 22px;
}

.group-1 .group-44 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 147px;
  width: 179px;
}

.group-1 .text-wrapper-54 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  left: 44px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 0;
  white-space: nowrap;
  width: 133px;
}

.group-1 .CTA-trade-5 {
  height: 59px;
  left: 28px;
  position: absolute;
  top: 342px;
  width: 247px;
}

.group-1 .overlap-group-6 {
  background: radial-gradient(50% 50% at 50% 50%, rgb(52, 107, 227) 0%, rgb(11, 23, 69) 100%);
  border-radius: 100px;
  height: 59px;
  position: relative;
  width: 245px;
}

.group-1 .text-wrapper-55 {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  height: 29px;
  left: 47px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 15px;
  width: 158px;
}
</style>
