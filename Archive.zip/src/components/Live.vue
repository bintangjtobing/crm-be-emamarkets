<template>
  <section id="live" class="live row-start-6 row-span-2 grid grid-rows-5 gap-1 place-items-center">
    <div class="text-2xl font-poppins font-normal text-center text-black -mt-96">
      <ul class="flex flex-wrap">
        <li class="me-2" v-for="(live, i) in lives" :key="`live-${i}`">
          <a
            :href="`${live}`"
            :class="`inline-block p-4 px-5 ${live == 'stocks' ? 'active' : ''}`"
            >{{ $t(`home.live.${live}.title`) }}</a
          >
        </li>
      </ul>
    </div>
    <div class="w-full mx-auto flex flex-wrap px-32 items-center justify-between -mt-80">
      <div class="grid grid-rows-3 grid-flow-col gap-x-64">
        <div class="row-span-3 pr-96"><GroupSix /></div>
        <div class="live-group-title px-4 py-6">{{ $t(`home.live.stocks.title`) }}</div>
        <div class="live-group-subtitle px-4 pt-2">
          {{ $t(`home.live.stocks.subtitle`) }}
        </div>
        <div class="live-group-action px-4 pt-2">
          <button
            class="bg-gradient-to-br from-blue-500 to-blue-950 hover:from-blue-950 hover:to-blue-500 delay-300 text-white text-lg py-2 px-6 rounded-full font-poppins"
          >
            {{ $t(`home.hero.action`) }}
          </button>
        </div>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import GroupSix from './Market/GroupSix.vue'
// import GroupSeven from './Market/GroupSeven.vue'
// import GroupEight from './Market/GroupEight.vue'
// import TrackTheLatest from './Market/TrackTheLatest.vue'

export default defineComponent({
  name: 'MarketLive',
  components: {
    GroupSix
    // GroupSeven,
    // GroupEight,
    // TrackTheLatest
  },
  data: function () {
    return {
      lives: ['currencies', 'metal', 'stocks', 'indices', 'commodities', 'energy', 'crypto']
    }
  }
})
</script>

<style>
.active {
  color: #043286;
  font-weight: 500;
}
.live-title {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 50px;
  font-weight: 500;
  /* left: 314px; */
  letter-spacing: 0;
  line-height: 56.8px;
  /* position: absolute;
  text-align: center;
  top: 0; */
  width: 647px;
  /* border-width: 5px;
  border-color: #000000; */
}

.live-group-title {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 40px;
  font-weight: 500;
  /* left: 673px; */
  letter-spacing: 0;
  line-height: 45.5px;
  /* position: absolute;
  top: 50px; */
  width: 602px;
}

.live-group-subtitle {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  /* font-weight: 400; */
  left: 673px;
  letter-spacing: 0;
  line-height: 31.2px;
  /* position: absolute;
  top: 121px; */
  width: 602px;
}

.live-group-action {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  /* height: 26px;
  left: 41px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 13px;
  width: 139px; */
}

.live-live {
  height: 721px;
  left: 118px;
  position: absolute;
  top: 1268px;
  width: 1279px;
}

.live-live .open-your-account-2 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  left: 140px;
  letter-spacing: 0;
  line-height: 34.3px;
  position: absolute;
  text-align: center;
  top: 140px;
  width: 996px;
}

.live-subtitle {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  /* left: 140px; */
  letter-spacing: 0;
  line-height: 34.3px;
  /* position: absolute;
  text-align: center;
  top: 140px; */
  width: 996px;
}
</style>
