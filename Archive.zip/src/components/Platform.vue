<template>
  <section
    id="platform"
    class="platform row-start-8 row-span-2 grid grid-rows-8 grid-flow-col gap-1 place-items-center text-center -mt-96"
  >
    <div
      class="platform-title row-start-2 row-span-2 text-center pb-2"
      v-html="
        $t(`home.platform.title`, {
          'black-start': '<span class=text-black>',
          'black-end': '</span>'
        })
      "
    ></div>
    <div class="platform-subtitle pt-2">
      {{ $t(`home.platform.subtitle`) }}
    </div>
    <div class="platform-action pt-2">
      <button
        class="text-center inline-flex items-center bg-gradient-to-br from-blue-500 to-blue-950 hover:from-blue-950 hover:to-blue-500 delay-300 text-white text-lg font-thin py-4 px-8 rounded-full font-poppins"
      >
        <svg
          class="me-2"
          width="38"
          height="41"
          viewBox="0 0 38 41"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M12.9952 4.80675L0 7.39952V19.395L12.9951 19.1763L12.9952 4.80675ZM37.0739 22.2279L15.9686 21.8667V36.7848L37.0739 41V22.2279ZM12.9952 21.8219L9.06336e-05 21.6012V33.5947L12.9952 36.1894V21.8219ZM37.0739 0L15.9686 4.21128V19.1294L37.0739 18.7702V0Z"
            fill="white"
          />
        </svg>

        {{ $t(`home.platform.action`) }}
      </button>
    </div>
    <div class="platform-action grid grid-cols-3 gap-1 place-content-center">
      <button
        type="button"
        class="text-center inline-flex items-center text-blue-700 hover:border hover:border-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-xs px-1 py-0.5 dark:border-blue-500 dark:text-blue-500 dark:hover:text-white dark:hover:bg-blue-500 dark:focus:ring-blue-800"
      >
        <svg
          class="me-2"
          width="27"
          height="27"
          viewBox="0 0 27 27"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M22.2765 0H4.08056C1.83053 0 0 1.83053 0 4.08056V22.2766C0 24.5265 1.83053 26.3571 4.08056 26.3571H22.2766C24.5265 26.3571 26.3571 24.5265 26.3571 22.2765V4.08056C26.3571 1.83053 24.5265 0 22.2765 0ZM24.8127 22.2765C24.8127 23.675 23.675 24.8127 22.2765 24.8127H4.08056C2.68209 24.8127 1.54436 23.675 1.54436 22.2765V8.16106H24.8127V22.2765ZM24.8127 6.6167H1.54436V4.08056C1.54436 2.68209 2.68209 1.54436 4.08056 1.54436H22.2766C23.675 1.54436 24.8127 2.68209 24.8127 4.08056V6.6167Z"
            fill="#3369E1"
          />
          <path
            d="M4.90756 3.30835H4.08051C3.05753 3.34608 3.05742 4.81492 4.08051 4.85271H4.90756C5.93055 4.81492 5.93065 3.34613 4.90756 3.30835Z"
            fill="black"
          />
          <path
            d="M8.62954 3.30835H7.80243C6.77945 3.34608 6.77935 4.81492 7.80243 4.85271H8.62954C9.65247 4.81492 9.65263 3.34613 8.62954 3.30835Z"
            fill="black"
          />
          <path
            d="M12.3515 3.30835H11.5244C10.5014 3.34608 10.5013 4.81492 11.5244 4.85271H12.3515C13.3744 4.81492 13.3745 3.34613 12.3515 3.30835Z"
            fill="black"
          />
        </svg>
        {{ $t(`home.platform.terminal`) }}</button
      ><button
        type="button"
        class="text-center inline-flex items-center text-blue-700 hover:border hover:border-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-xs px-1 py-0.5 ml-5 dark:border-blue-500 dark:text-blue-500 dark:hover:text-white dark:hover:bg-blue-500 dark:focus:ring-blue-800"
      >
        <svg
          class="me-2"
          width="22"
          height="27"
          viewBox="0 0 22 27"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M15.8174 0C15.8788 0 15.9401 0 16.0049 0C16.1554 1.85896 15.4459 3.24798 14.5835 4.25385C13.7374 5.25278 12.5787 6.22162 10.7047 6.07462C10.5797 4.24228 11.2904 2.95628 12.1516 1.95272C12.9503 1.01745 14.4145 0.185202 15.8174 0Z"
            fill="#3369E1"
          />
          <path
            d="M21.4904 19.3489C21.4904 19.3675 21.4904 19.3837 21.4904 19.401C20.9637 20.9961 20.2125 22.3631 19.2957 23.6317C18.4588 24.7834 17.4333 26.3334 15.6021 26.3334C14.0198 26.3334 12.9688 25.3159 11.3471 25.2881C9.63165 25.2603 8.68828 26.1389 7.11985 26.36C6.94044 26.36 6.76102 26.36 6.58508 26.36C5.43336 26.1933 4.50388 25.2812 3.82673 24.4593C1.83002 22.0309 0.287063 18.894 0 14.8798C0 14.4862 0 14.0938 0 13.7003C0.121539 10.8273 1.5175 8.49148 3.37299 7.35943C4.35224 6.75753 5.69843 6.24475 7.1974 6.47394C7.83982 6.57348 8.49613 6.79341 9.07141 7.01102C9.6166 7.22053 10.2984 7.59209 10.9443 7.57241C11.3818 7.55968 11.817 7.33165 12.258 7.17076C13.5498 6.70428 14.8161 6.16951 16.4853 6.42069C18.4912 6.72396 19.915 7.61524 20.7947 8.99036C19.0978 10.0703 17.7562 11.6978 17.9854 14.477C18.1891 17.0015 19.6569 18.4785 21.4904 19.3489Z"
            fill="#3369E1"
          />
        </svg>
        {{ $t(`home.platform.macos`) }}</button
      ><button
        type="button"
        class="text-center inline-flex items-center text-blue-700 hover:border hover:border-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-xs px-1 py-0.5 ml-4 dark:border-blue-500 dark:text-blue-500 dark:hover:text-white dark:hover:bg-blue-500 dark:focus:ring-blue-800"
      >
        <svg
          class="me-2"
          width="23"
          height="27"
          viewBox="0 0 23 27"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M21.8766 21.502C21.1799 21.2161 20.6058 20.7659 20.6475 19.9036C20.688 19.0424 20.0317 18.4718 20.0317 18.4718C20.0317 18.4718 20.6058 16.5863 20.0723 15.0296C19.5399 13.4705 17.7782 10.9728 16.4263 9.0884C15.0767 7.20296 16.2226 5.03045 14.9945 2.24561C13.7642 -0.539218 10.5696 -0.375988 8.84853 0.812651C7.12631 1.9991 7.65874 4.94826 7.73978 6.34407C7.82197 7.73533 7.77693 8.72703 7.61819 9.08726C7.45611 9.44748 6.34846 10.769 5.61006 11.8743C4.87276 12.9797 4.34033 15.2749 3.80565 16.2171C3.27322 17.1592 3.64242 18.0192 3.64242 18.0192C3.64242 18.0192 3.27322 18.1408 2.98616 18.7588C2.6991 19.3711 2.12617 19.6582 1.10186 19.8608C0.0775487 20.0657 0.0775485 20.7242 0.322916 21.4615C0.569432 22.1976 0.324064 22.6096 0.0370018 23.5495C-0.25006 24.4895 1.18405 24.7787 2.57647 24.9397C3.97003 25.1052 5.52677 26.0068 6.8393 26.17C8.14843 26.3344 8.55927 25.2695 8.55927 25.2695C8.55927 25.2695 10.0339 24.9397 11.5895 24.9014C13.1474 24.8598 14.6198 25.229 14.6198 25.229C14.6198 25.229 14.9068 25.8841 15.4393 26.17C15.9728 26.4571 17.1198 26.4987 17.8571 25.722C18.5955 24.9419 20.5621 23.9604 21.6674 23.3447C22.776 22.7279 22.5734 21.7868 21.8766 21.502ZM12.2884 3.43436C12.9908 3.43436 13.5582 4.13111 13.5582 4.99001C13.5582 5.60008 13.2734 6.12578 12.858 6.38127C12.7522 6.33514 12.6408 6.28786 12.5226 6.23719C12.7725 6.11336 12.9503 5.79483 12.9503 5.42334C12.9503 4.93933 12.6509 4.54644 12.2805 4.54644C11.9147 4.54644 11.6142 4.94043 11.6142 5.42334C11.6142 5.60233 11.6569 5.77453 11.7301 5.91522C11.5117 5.82854 11.3102 5.7475 11.1526 5.68786C11.0671 5.4785 11.0187 5.2421 11.0187 4.98995C11.0187 4.13111 11.586 3.43436 12.2884 3.43436ZM12.1973 6.71447C12.5484 6.83605 12.939 7.06457 12.8986 7.29078C12.8569 7.51815 12.6723 7.51815 12.1973 7.8086C11.7211 8.09676 10.69 8.73611 10.3602 8.77775C10.0281 8.8194 9.84351 8.63368 9.49231 8.40741C9.14112 8.18004 8.48037 7.64083 8.64694 7.35382C8.64694 7.35382 9.16137 6.95983 9.38763 6.75386C9.615 6.54675 10.1936 6.05257 10.5448 6.11675C10.896 6.1764 11.8461 6.59063 12.1973 6.71447ZM9.0308 3.68087C9.58463 3.68087 10.0349 4.34048 10.0349 5.15433C10.0349 5.30405 10.0203 5.44249 9.99208 5.57644C9.85703 5.62258 9.71968 5.69688 9.58687 5.80944C9.51935 5.8646 9.45965 5.91637 9.40225 5.96814C9.49007 5.80381 9.52493 5.56966 9.48553 5.32315C9.41122 4.87854 9.11518 4.55432 8.82139 4.60051C8.52874 4.65118 8.352 5.05075 8.42631 5.49765C8.50171 5.94455 8.79665 6.26871 9.0893 6.22029C9.10621 6.21689 9.12197 6.21241 9.13882 6.20677C8.99589 6.34412 8.86418 6.46231 8.73022 6.56245C8.32502 6.37449 8.02783 5.81503 8.02783 5.15313C8.02788 4.33938 8.47698 3.68087 9.0308 3.68087ZM7.94909 24.3825C7.81852 24.9701 7.13074 25.3967 7.13074 25.3967C6.50715 25.5926 4.77366 24.8407 3.98793 24.5109C3.20335 24.1856 1.20534 24.0843 0.943067 23.7938C0.683036 23.4966 1.07363 22.8427 1.17382 22.2224C1.27062 21.5977 0.977978 21.2071 1.07478 20.7805C1.17382 20.3561 2.45029 20.3561 2.93998 20.0623C3.43186 19.7663 3.52981 18.9153 3.92265 18.6868C4.31549 18.456 5.03479 19.2744 5.32968 19.7348C5.62347 20.1906 6.7367 22.156 7.19488 22.6468C7.65415 23.1376 8.07965 23.795 7.94909 24.3825ZM15.1948 18.6733C15.0766 19.2508 15.0766 21.3377 15.0766 21.3377C15.0766 21.3377 13.8069 23.0971 11.8382 23.3852C9.87169 23.6734 8.88787 23.4663 8.88787 23.4663L7.78246 22.1977C7.78246 22.1977 8.6413 22.0727 8.51977 21.2128C8.39594 20.3528 5.89816 19.1641 5.44678 18.0981C4.99763 17.0344 5.36574 15.23 5.93981 14.3283C6.51278 13.4278 6.87974 11.4624 7.45381 10.805C8.02788 10.1522 8.47703 8.7586 8.27216 8.14289C8.27216 8.14289 9.50134 9.61859 10.3602 9.37432C11.2202 9.1278 13.1485 7.6926 13.4332 7.94026C13.7191 8.18678 16.1776 13.5932 16.4218 15.3143C16.6683 17.0343 16.2575 18.3446 16.2575 18.3446C16.2575 18.3446 15.3164 18.0992 15.1948 18.6733ZM21.4827 22.5331C21.0999 22.8843 18.9702 23.7443 18.332 24.4152C17.6971 25.0804 16.8675 25.6219 16.3598 25.4643C15.8488 25.3033 15.4041 24.6043 15.627 23.5845C15.8488 22.568 16.0413 21.4536 16.0097 20.8165C15.9782 20.1794 15.8488 19.3182 16.0097 19.1911C16.1685 19.0672 16.4217 19.1292 16.4217 19.1292C16.4217 19.1292 16.2968 20.337 17.0273 20.6578C17.7578 20.973 18.8092 20.5306 19.1278 20.2098C19.4474 19.8935 19.6703 19.4162 19.6703 19.4162C19.6703 19.4162 19.9878 19.5772 19.9562 20.0849C19.9247 20.5936 20.178 21.3276 20.6575 21.5809C21.1337 21.8319 21.8654 22.1842 21.4827 22.5331Z"
            fill="#3369E1"
          />
        </svg>
        {{ $t(`home.platform.linux`) }}
      </button>
    </div>
    <div class="platform-action grid grid-cols-3 gap-1">
      <button
        type="button"
        class="text-left inline-flex items-center bg-black text-white text-xs font-thin py-2 px-4 mr-2 rounded-full font-poppins w-36"
      >
        <svg
          class="me-1"
          width="32"
          height="38"
          viewBox="0 0 16 19"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M11.1908 0C11.2342 0 11.2776 0 11.3234 0C11.4299 1.31522 10.9279 2.29794 10.3178 3.0096C9.71914 3.71634 8.89938 4.40179 7.57352 4.29779C7.48507 3.00141 7.9879 2.09157 8.59719 1.38155C9.16226 0.719847 10.1982 0.13103 11.1908 0Z"
            fill="#F5F5F7"
          />
          <path
            d="M15.2044 13.6894C15.2044 13.7025 15.2044 13.7139 15.2044 13.7262C14.8318 14.8547 14.3003 15.8219 13.6517 16.7194C13.0596 17.5343 12.334 18.6308 11.0384 18.6308C9.91895 18.6308 9.17536 17.911 8.02802 17.8913C6.81436 17.8717 6.14692 18.4933 5.03726 18.6497C4.91033 18.6497 4.78339 18.6497 4.65891 18.6497C3.84407 18.5318 3.18646 17.8864 2.70738 17.305C1.29471 15.5869 0.203066 13.3675 -3.05176e-05 10.5274C-3.05176e-05 10.249 -3.05176e-05 9.97139 -3.05176e-05 9.69295C0.085958 7.66034 1.0736 6.00773 2.38636 5.2068C3.07918 4.78096 4.0316 4.41817 5.09213 4.58032C5.54664 4.65075 6.01098 4.80634 6.41799 4.9603C6.80371 5.10853 7.28607 5.37141 7.74303 5.35749C8.05259 5.34848 8.36051 5.18715 8.67253 5.07332C9.58646 4.74329 10.4824 4.36494 11.6633 4.54265C13.0825 4.75721 14.0898 5.38779 14.7122 6.36069C13.5116 7.12476 12.5625 8.27619 12.7246 10.2425C12.8688 12.0286 13.9072 13.0735 15.2044 13.6894Z"
            fill="#F5F5F7"
          />
        </svg>
        {{ $t(`home.platform.store`) }}</button
      ><button
        type="button"
        class="text-left inline-flex items-center bg-black text-white text-xs font-thin py-2 px-4 mr-2 rounded-full font-poppins w-36"
      >
        <svg
          class="me-3"
          width="36"
          height="38"
          viewBox="0 0 18 19"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M3.48458 0.476807C3.07744 0.213719 2.5884 0.134203 2.1297 0.242482L10.1906 8.30346L12.8032 5.69088L3.48458 0.476807Z"
            fill="#F5F5F7"
          />
          <path
            d="M1.12913 0.897705C0.904299 1.19661 0.774902 1.56361 0.774902 1.95184V16.3108C0.774902 16.699 0.904334 17.066 1.12913 17.3649L9.36269 9.13133L1.12913 0.897705Z"
            fill="#F5F5F7"
          />
          <path
            d="M16.2128 7.59867L13.8648 6.28491L11.0184 9.1313L13.865 11.9778L16.2132 10.664C16.7758 10.3488 17.1116 9.77588 17.1116 9.1313C17.1116 8.48672 16.7758 7.91388 16.2128 7.59867Z"
            fill="#F5F5F7"
          />
          <path
            d="M10.1906 9.95923L2.13013 18.0197C2.26228 18.0508 2.39677 18.0675 2.53127 18.0675C2.86364 18.0675 3.19487 17.973 3.48455 17.7858L12.8033 12.5718L10.1906 9.95923Z"
            fill="#F5F5F7"
          />
        </svg>
        {{ $t(`home.platform.play`) }}</button
      ><button
        type="button"
        class="text-center inline-flex items-center border border-black text-black text-xs font-normal underline py-2 px-4 rounded-full font-poppins w-36"
      >
        {{ $t(`home.platform.apk`) }}
      </button>
    </div>
    <div
      class="platform-showcase row-span-8 overflow-visible before:rounded-xl pt-4 pb-16 mr-5 w-10/12 relative bg-[url(/src/assets/img/mask-group-2.png)] bg-right-bottom bg-contain before:content-[''] before:inset-0 before:block before:bg-gradient-to-br before:from-blue-700 before:to-blue-950 before:opacity-95 before:z-[-5] before:absolute"
    >
      <img class="overflow-visible light -ml-14" alt="Light" src="@/assets/img/light-01-1.png" />
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Platform'
})
</script>

<style>
/* .platform {
  height: 615px;
  left: 122px;
  position: absolute;
  top: 2077px;
  width: 1286px;
} */

.platform .div-8 {
  height: 615px;
  position: relative;
}

.platform .group-64 {
  height: 615px;
  left: 564px;
  position: absolute;
  top: 0;
  width: 722px;
}

.platform .rectangle-6 {
  background: radial-gradient(50% 50% at 50% 50%, rgb(52, 107, 227) 0%, rgb(11, 23, 69) 100%);
  border-radius: 15px;
  height: 550px;
  left: 83px;
  position: absolute;
  top: 65px;
  width: 639px;
}

.platform .mask-group-2 {
  height: 615px;
  /* left: 83px;
  position: absolute;
  top: 0; */
  width: 639px;
}

.platform .light {
  height: 435px;
  /* left: 0; */
  object-fit: cover;
  /* position: absolute; */
  /* top: 90px; */
  width: 722px;
}

.platform .group-65 {
  height: 470px;
  left: 0;
  position: absolute;
  top: 121px;
  width: 501px;
}

.platform .group-66 {
  height: 87px;
  left: 83px;
  position: absolute;
  top: 383px;
  width: 337px;
}

.platform .overlap-group-13 {
  height: 87px;
  position: relative;
  width: 339px;
}

.platform .group-67 {
  height: 87px;
  left: 60px;
  position: absolute;
  top: 0;
  width: 279px;
}

.platform .group-68 {
  background-color: #000000;
  border-radius: 10px;
  height: 53px;
  left: 115px;
  position: absolute;
  top: 0;
  width: 162px;
}

.platform .group-69 {
  height: 20px;
  left: 21px;
  position: relative;
  top: 15px;
  width: 135px;
}

.platform .text-wrapper-95 {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 14px;
  font-weight: 400;
  height: 20px;
  left: 22px;
  letter-spacing: 0;
  line-height: 15.9px;
  position: absolute;
  top: 0;
  width: 111px;
}

.platform .group-70 {
  height: 18px;
  left: 0;
  position: absolute;
  top: 1px;
  width: 16px;
}

.platform .text-wrapper-96 {
  color: #5f5f5f;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  height: 17px;
  left: 0;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  text-align: center;
  text-decoration: underline;
  top: 70px;
  white-space: nowrap;
}

.platform .group-71 {
  height: 53px;
  left: 0;
  position: absolute;
  top: 0;
  width: 162px;
}

.platform .group-72 {
  background-color: #000000;
  border-radius: 10px;
  height: 53px;
}

.platform .group-73 {
  height: 19px;
  left: 0;
  position: absolute;
  top: 1px;
  width: 15px;
}

.platform .seamless-trading {
  color: transparent;
  font-family: 'Poppins', Helvetica;
  font-size: 50px;
  font-weight: 500;
  left: 0;
  letter-spacing: 0;
  line-height: 56.8px;
  position: absolute;
  text-align: center;
  top: 0;
}

.platform .text-wrapper-97 {
  color: #043286;
}

.platform .text-wrapper-98 {
  color: #000000;
}

.platform .text-wrapper-99 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  left: 19px;
  letter-spacing: 0;
  line-height: 28.4px;
  position: absolute;
  text-align: center;
  top: 136px;
  width: 465px;
}

.platform .group-74 {
  background-color: #043286;
  border-radius: 100px;
  height: 73px;
  left: 12px;
  position: absolute;
  top: 222px;
  width: 479px;
}

.platform .group-75 {
  height: 41px;
  left: 52px;
  position: relative;
  top: 16px;
  width: 377px;
}

.platform .text-wrapper-100 {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 400;
  height: 37px;
  left: 58px;
  letter-spacing: 0;
  line-height: 19.3px;
  position: absolute;
  top: 1px;
  width: 317px;
}

.platform .group-76 {
  height: 41px;
  left: 0;
  position: absolute;
  top: 0;
  width: 37px;
}

.platform .group-77 {
  height: 26px;
  left: 53px;
  position: absolute;
  top: 326px;
  width: 397px;
}

.platform .group-78 {
  height: 26px;
  left: 0;
  position: absolute;
  top: 0;
  width: 129px;
}

.platform .group-79 {
  height: 26px;
  left: 0;
  position: absolute;
  top: 0;
  width: 26px;
}

.platform .text-wrapper-101 {
  color: #3369e1;
  font-family: 'Poppins', Helvetica;
  font-size: 13px;
  font-weight: 400;
  height: 15px;
  left: 40px;
  letter-spacing: 0;
  line-height: 14.8px;
  position: absolute;
  top: 5px;
  white-space: nowrap;
}

.platform .group-80 {
  height: 26px;
  left: 163px;
  position: absolute;
  top: 0;
  width: 109px;
}

.platform .group-81 {
  height: 26px;
  left: 0;
  position: absolute;
  top: 0;
  width: 21px;
}

.platform .text-wrapper-102 {
  color: #3369e1;
  font-family: 'Poppins', Helvetica;
  font-size: 13px;
  font-weight: 400;
  height: 15px;
  left: 35px;
  letter-spacing: 0;
  line-height: 14.8px;
  position: absolute;
  top: 5px;
  white-space: nowrap;
}

.platform .group-82 {
  height: 26px;
  left: 306px;
  position: absolute;
  top: 0;
  width: 93px;
}

.platform .text-wrapper-103 {
  color: #3369e1;
  font-family: 'Poppins', Helvetica;
  font-size: 13px;
  font-weight: 400;
  height: 15px;
  left: 36px;
  letter-spacing: 0;
  line-height: 14.8px;
  position: absolute;
  top: 5px;
  white-space: nowrap;
}

.platform .group-83 {
  height: 26px;
  left: 0;
  position: absolute;
  top: 0;
  width: 22px;
}

.platform-title {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 50px;
  font-weight: 500;
  /* left: 673px; */
  letter-spacing: 0;
  line-height: 56.8px;
  /* position: absolute;
  top: 50px; */
  width: 602px;
}

.platform-subtitle {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  /* font-weight: 400; */
  left: 673px;
  letter-spacing: 0;
  line-height: 31.2px;
  /* position: absolute;
  top: 121px; */
  width: 602px;
}

.platform-action {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  /* height: 26px;
  left: 41px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 13px;
  width: 139px; */
}

/* .platform-showcase {
  background-image: url(@/assets/img/mask-group-2.png);
} */
</style>
