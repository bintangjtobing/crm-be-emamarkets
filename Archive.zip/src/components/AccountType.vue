<template>
  <section
    id="account"
    class="account row-start-10 row-span-2 grid grid-rows-12 gap-1 place-items-center"
  >
    <div
      class="account-title text-center row-span-2 w-5/12"
      v-html="
        $t(`home.account.title`, {
          'black-start': '<span class=text-black>',
          'black-end': '</span>'
        })
      "
    ></div>
    <div class="account-subtitle text-center row-span-2 pt-2">
      {{ $t(`home.account.subtitle`) }}
    </div>
    <div class="account-showcase row-span-8 grid grid-cols-4 gap-5 place-items-center">
      <div
        class="p-8 w-full bg-white border border-gray-200 rounded-xl shadow-xl"
        v-for="(type, ti) in accounts"
        :key="`account-${ti}`"
      >
        <h5 class="account-showcase-title text-center mt-4">
          {{ $t(`home.account.${type}.title`) }}
        </h5>
        <h6 class="account-showcase-subtitle text-center mb-4">
          {{ $t(`home.account.${type}.subtitle`) }}
        </h6>
        <ul
          role="list"
          class="space-y-5 my-7 list-image-[url(@/assets/img/checkmark.svg)] list-inside"
        >
          <li
            class="account-showcase-list"
            v-for="(describe, di) in descriptions"
            :key="`describe-${di}`"
          >
            {{ $t(`home.account.${type}.${describe}`) }}
          </li>
        </ul>
        <button
          class="bg-gradient-to-br from-blue-500 to-blue-950 hover:from-blue-950 hover:to-blue-500 delay-300 text-white text-lg rounded-full font-poppins px-6 py-2.5 inline-flex justify-center w-full text-center"
        >
          {{ $t(`home.account.${type}.action`) }}
        </button>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
// import MaximizeYour from './Account/MaximizeYour.vue'
// import GroupTwo from './Account/GroupTwo.vue'

export default defineComponent({
  name: 'AccountType',
  components: {
    // MaximizeYour,
    // GroupTwo
  },
  data: function () {
    return {
      accounts: ['micro', 'standard', 'professional', 'raw'],
      descriptions: ['leverage', 'spreads', 'deposit', 'commission']
    }
  }
})
</script>

<style>
.account-type {
  height: 678px;
  left: 104px;
  position: absolute;
  top: 2867px;
  width: 1291px;
}

.account-title {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 50px;
  font-weight: 500;
  /* left: 357px; */
  letter-spacing: 0;
  line-height: 56.8px;
  /* position: absolute;
  text-align: center;
  top: 0; */
}

.account-showcase-title {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 20px;
  font-weight: 500;
  /* left: 56px; */
  letter-spacing: 0;
  line-height: 22.7px;
  /* position: absolute;
  text-align: center;
  top: 35px; */
  white-space: nowrap;
  /* width: 191px; */
}

.account-showcase-subtitle {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  /* left: 117px; */
  letter-spacing: 0;
  line-height: 17px;
  /* position: absolute;
  text-align: center;
  top: 63px; */
  white-space: nowrap;
  /* width: 67px; */
}

.account-showcase-list {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 400;
  /* left: 44px; */
  letter-spacing: 0;
  /* line-height: 17px;
  position: absolute;
  top: 0; */
  white-space: nowrap;
  /* width: 181px; */
}

.account-subtitle {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  /* left: 224px; */
  letter-spacing: 0;
  line-height: 34.3px;
  /* position: absolute;
  text-align: center;
  top: 142px; */
  width: 889px;
}
</style>
