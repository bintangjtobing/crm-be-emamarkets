<template>
  <section id="market" class="market row-start-5 grid grid-rows-5 gap-1 place-items-center">
    <div
      class="market-title text-center -mt-16 pb-2"
      v-html="
        $t(`home.market.title`, {
          'black-start': '<span class=text-black>',
          'black-end': '</span>'
        })
      "
    ></div>
    <div class="market-subtitle text-center -mt-2">
      {{ $t(`home.market.subtitle`) }}
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
// import GroupSix from './Market/GroupSix.vue'
// import GroupSeven from './Market/GroupSeven.vue'
// import GroupEight from './Market/GroupEight.vue'
// import TrackTheLatest from './Market/TrackTheLatest.vue'

export default defineComponent({
  name: 'MarketLive',
  components: {
    // GroupSix,
    // GroupSeven,
    // GroupEight,
    // TrackTheLatest
  }
})
</script>

<style>
.active {
  color: #043286;
  font-weight: 500;
}
.market-title {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 50px;
  font-weight: 500;
  /* left: 314px; */
  letter-spacing: 0;
  line-height: 56.8px;
  /* position: absolute;
  text-align: center;
  top: 0; */
  width: 647px;
  /* border-width: 5px;
  border-color: #000000; */
}

.market-group-title {
  color: #000000;
  font-family: 'Poppins', Helvetica;
  font-size: 40px;
  font-weight: 500;
  /* left: 673px; */
  letter-spacing: 0;
  line-height: 45.5px;
  /* position: absolute;
  top: 50px; */
  width: 602px;
}

.market-group-subtitle {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  /* font-weight: 400; */
  left: 673px;
  letter-spacing: 0;
  line-height: 31.2px;
  /* position: absolute;
  top: 121px; */
  width: 602px;
}

.market-group-action {
  color: #f5f5f7;
  font-family: 'Poppins', Helvetica;
  font-size: 17px;
  font-weight: 600;
  /* height: 26px;
  left: 41px;
  letter-spacing: 0;
  line-height: normal;
  position: absolute;
  text-align: center;
  top: 13px;
  width: 139px; */
}

.market-live {
  height: 721px;
  left: 118px;
  position: absolute;
  top: 1268px;
  width: 1279px;
}

.market-live .open-your-account-2 {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  left: 140px;
  letter-spacing: 0;
  line-height: 34.3px;
  position: absolute;
  text-align: center;
  top: 140px;
  width: 996px;
}

.market-subtitle {
  color: #424245;
  font-family: 'Poppins', Helvetica;
  font-size: 25px;
  font-weight: 400;
  /* left: 140px; */
  letter-spacing: 0;
  line-height: 34.3px;
  /* position: absolute;
  text-align: center;
  top: 140px; */
  width: 996px;
}
</style>
