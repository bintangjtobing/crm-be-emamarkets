<template>
  <footer class="footer">
    <div class="max-w-7xl mx-auto p-4 flex flex-wrap items-center justify-between">
      <div class="grid grid-rows-12 gap-1">
        <Sitemap />
        <!-- <div> -->
        <hr class="w-full top-28" />
        <!-- </div> -->
        <!-- <hr class="h-5 my-8 bg-white" /> -->
        <Disclaimer />
      </div>
    </div>
  </footer>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import Sitemap from './Footer/Sitemap.vue'
import Disclaimer from './Footer/Disclaimer.vue'

export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Footing',
  components: {
    Sitemap,
    Disclaimer
  }
})
</script>

<style>
.footer {
  background: rgb(11, 23, 69);
  background-image: url(@/assets/img/mask-group.png);
  background-size: 100% 100%;
}
</style>
