<template>
  <header class="sticky top-0 z-10 bg-slate-100">
    <!-- navbar goes here -->
    <nav class="bg-white shadow-md">
      <div class="max-w-7xl mx-auto p-4 flex flex-wrap items-center justify-between">
        <div class="flex justify-between">
          <!-- primary nav -->
          <div class="flex space-x-4">
            <!-- logo -->
            <RouterLink to="/">
              <img class="pt-3" alt="𝗘𝗠𝗔𝖬𝖺𝗋𝗄𝖾𝗍𝗌" width="160" src="@/assets/ema-markets.svg" />
            </RouterLink>

            <div
              class="group-menu hidden w-full md:block md:w-auto"
              v-for="(group, gk, gi) in groups"
              :key="`group-${gi}`"
              id="navbar-default"
            >
              <button class="px-1 py-5 md:flex items-center space-x-1">
                <span
                  class="font-semibold text-black hover:text-blue-900 hover:font-black flex-1"
                  >{{ $t(`header.links.${gk}`) }}</span
                >
                <span>
                  <svg
                    class="fill-current h-4 w-4 transform group-hover:-rotate-180 transition duration-150 ease-in-out"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                  >
                    <path
                      d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                    />
                  </svg>
                </span>
              </button>
              <ul
                v-if="group"
                class="bg-white border rounded-sm transform scale-0 group-hover:scale-100 absolute transition duration-150 ease-in-out origin-top min-w-32"
              >
                <li
                  v-for="(menu, mk, mi) in group"
                  :key="`menu-${mi}`"
                  class="rounded-sm px-3 py-1 hover:bg-gray-100"
                >
                  <button
                    v-if="menu"
                    class="w-full text-left flex items-center outline-none focus:outline-none"
                  >
                    <span class="pr-1 flex-1">{{ $t(`header.links.${mk}`) }}</span>
                    <span class="mr-auto">
                      <svg
                        class="fill-current h-4 w-4 transition duration-150 ease-in-out"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                      >
                        <path
                          d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                        />
                      </svg>
                    </span>
                  </button>
                  <ul
                    v-if="menu"
                    class="bg-white border rounded-sm absolute right-0 transition duration-150 ease-in-out origin-top-left min-w-32"
                  >
                    <li
                      v-for="(sub, sk, si) in menu"
                      :key="`sub-${si}`"
                      class="rounded-sm relative px-3 py-1 hover:bg-gray-100"
                    >
                      <button
                        v-if="sub"
                        class="w-full text-left flex items-center outline-none focus:outline-none"
                      >
                        <span class="pr-1 flex-1">{{ $t(`header.links.${sk}`) }}</span>
                        <span class="mr-auto">
                          <svg
                            class="fill-current h-4 w-4 transition duration-150 ease-in-out"
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                          >
                            <path
                              d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                            />
                          </svg>
                        </span>
                      </button>
                      <ul
                        v-if="sub"
                        class="bg-white border rounded-sm absolute top-0 right-0 transition duration-150 ease-in-out origin-top-left min-w-32"
                      >
                        <li
                          v-for="(cat, ck, ci) in sub"
                          :key="`sub-${ci}`"
                          class="rounded-sm relative px-3 py-1 hover:bg-gray-100"
                        >
                          <button
                            v-if="cat"
                            class="w-full text-left flex items-center outline-none focus:outline-none"
                          >
                            <span class="pr-1 flex-1">{{ $t(`header.links.${ck}`) }}</span>
                            <span class="mr-auto">
                              <svg
                                class="fill-current h-4 w-4 transition duration-150 ease-in-out"
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 20 20"
                              >
                                <path
                                  d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                                />
                              </svg>
                            </span>
                          </button>
                          <ul
                            v-if="cat"
                            class="bg-white border rounded-sm absolute top-0 right-0 transition duration-150 ease-in-out origin-top-left min-w-32"
                          >
                            <li
                              v-for="(part, pk, pi) in cat"
                              :key="`part-${pi}`"
                              class="rounded-sm relative px-3 py-1 hover:bg-gray-100"
                            >
                              <span class="pr-1 flex-1">{{ $t(`header.links.${pk}`) }}</span>
                            </li>
                          </ul>
                          <span v-else class="pr-1 flex-1">{{ $t(`header.links.${ck}`) }}</span>
                        </li>
                      </ul>
                      <span v-else class="pr-1 flex-1">{{ $t(`header.links.${sk}`) }}</span>
                    </li>
                  </ul>
                  <span v-else class="pr-1 flex-1">{{ $t(`header.links.${mk}`) }}</span>
                </li>
              </ul>
            </div>
          </div>
          <!-- secondary nav -->
          <div class="items-center hidden space-x-1 md:flex">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              class="size-6"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"
              />
            </svg>
            <div @click="login" class="px-3 py-5 text-black hover:text-blue-900 hover:font-black">
              {{ $t(`header.links.login`) }}
            </div>
            <RouterLink
              to="/"
              class="px-3 py-2 text-white transition duration-300 bg-blue-900 rounded-full hover:bg-blue-800 hover:font-black"
            >
              {{ $t(`header.links.register`) }}
            </RouterLink>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              class="size-6"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                d="M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 0 1 7.843 4.582M12 3a8.997 8.997 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-1.605.42-3.113 1.157-4.418"
              />
            </svg>
            <select v-model="$i18n.locale">
              <option v-for="(lang, i) in langs" :key="`Lang${i}`" :value="lang.id">
                {{ lang.text }}
              </option>
            </select>
          </div>
        </div>
        <!-- mobile button goes here -->
        <div class="md:hidden flex items-center">
          <button class="mobile-menu-button">
            <svg
              class="w-6 h-6"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
        </div>
        <!-- mobile menu -->
        <div class="mobile-menu hidden md:hidden">
          <RouterLink
            to="/"
            v-for="(group, k, i) in groups"
            :key="`group-${i}`"
            class="block py-2 px-4 text-sm hover:bg-gray-200"
            >{{ $t(`header.links.${k}`) }}</RouterLink
          >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke-width="1.5"
            stroke="currentColor"
            class="size-6"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              d="M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 0 1 7.843 4.582M12 3a8.997 8.997 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-1.605.42-3.113 1.157-4.418"
            />
          </svg>
          <select v-model="$i18n.locale" :onchange="direction($i18n.locale)">
            <option v-for="(lang, i) in langs" :key="`lang-${i}`" :value="lang.id">
              {{ lang.text }}
            </option>
          </select>
        </div>
      </div>
    </nav>
  </header>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import headings from '@/assets/headings.json'
import languages from '@/assets/languages.json'
import $ from 'jquery'
import axios from 'axios'

const heading: any = headings
const language: any = languages

export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Heading',
  components: {},
  data() {
    return {
      langs: language,
      groups: heading
    }
  },
  methods: {
    async login() {
      try {
        const response = await axios.post(
          '/syntellicore.cfc?method=user_login', // Use relative path
          new URLSearchParams({
            login: 'bintang.tobing',
            password: 'Duhani33'
          }),
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
              api_key: '5C9F6D90-5A83-4ECA-8741-8E09627AE5F2'
            }
          }
        )
        console.log('Example Purpose: API Test login successful', response.data)
      } catch (error) {
        console.error('Example Purpose: API Test login failed', error)
      }
    },
    direction(code: string) {
      $('html')
        .attr('dir', code == 'ur' ? 'rtl' : 'ltr')
        .attr('lang', code)
    }
  }
})
</script>

<style>
.mainpage .header {
  height: 86px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1512px;
}
/* since nested groups are not supported we have to use 
     regular css for the nested dropdowns 
  */
li > ul {
  transform: translatex(100%) scale(0);
}
li:hover > ul {
  transform: translatex(101%) scale(1);
}
li > button svg {
  transform: rotate(-90deg);
}
li:hover > button svg {
  transform: rotate(-270deg);
}

/* Below styles fake what can be achieved with the tailwind config
     you need to add the group-hover variant to scale and define your custom
     min width style.
  	 See https://codesandbox.io/s/tailwindcss-multilevel-dropdown-y91j7?file=/index.html
  	 for implementation with config file
  */
/* .group:hover .group-hover\:scale-100 {
  transform: scale(1);
}
.group:hover .group-hover\:-rotate-180 {
  transform: rotate(180deg);
} */
.group-menu:hover .group-hover\:scale-100 {
  transform: scale(1);
}
.group-menu:hover .group-hover\:-rotate-180 {
  transform: rotate(180deg);
}
.scale-0 {
  transform: scale(0);
}
.min-w-32 {
  min-width: 8rem;
}
</style>
