<template>
  <section id="usp" class="usp row-start-4 grid grid-rows-3 gap-0">
    <div
      class="row-start-2 grid grid-cols-5 gap-3 shadow-xl rounded-2xl px-16 place-items-center items-center justify-center"
    >
      <div class="grid grid-cols-4 gap-3" v-for="(usp, k, i) in usps" :key="`usp-${i}`">
        <img
          class="responsive-clock"
          :alt="$t(`home.usp.${k}`)"
          :src="`src/assets/img/${usp}.png`"
        />
        <span class="col-start-2 col-span-3 text-wrapper-usp pt-4 text-wrap">{{
          $t(`home.usp.${k}`)
        }}</span>
      </div>
    </div>
  </section>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  // eslint-disable-next-line vue/multi-word-component-names
  name: 'Usp',
  data() {
    return {
      usps: {
        'fast-executions': 'responsive-clock-01-2',
        'stable-spreads': 'spreads-01-1-1',
        'no-overnight-fees': 'novernightfees-02-1-1',
        'negative-balance-protenction': 'spreads-01-1-1',
        'mfsc-regulated': 'novernightfees-02-1-1'
      }
    }
  }
})
</script>

<style>
.text-wrapper-usp {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 500;
  /* left: 60px; */
  letter-spacing: 0;
  line-height: 17px;
  /* position: absolute; */
  /* top: 17px; */
  white-space: nowrap;
}
.USP {
  background-color: #ffffff;
  border-radius: 15px;
  box-shadow: 0px 8px 8px #00000026;
  height: 102px;
  /* left: 113px; */
  position: absolute;
  /* top: 1053px; */
  width: 1304px;
}

.USP .group-84 {
  height: 56px;
  left: 81px;
  position: relative;
  top: 25px;
  width: 1142px;
}

.USP .group-85 {
  height: 56px;
  position: relative;
}

.USP .group-86 {
  height: 50px;
  left: 0;
  position: absolute;
  top: 3px;
  width: 178px;
}

.USP .text-wrapper-104 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 500;
  left: 60px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 17px;
  white-space: nowrap;
}

.USP .responsive-clock {
  height: 50px;
  left: 0;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 50px;
}

.USP .group-87 {
  height: 56px;
  left: 219px;
  position: absolute;
  top: 0;
  width: 197px;
}

.USP .text-wrapper-105 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 500;
  left: 65px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 21px;
  white-space: nowrap;
  width: 130px;
}

.USP .img-2 {
  height: 56px;
  left: 0;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 56px;
}

.USP .group-88 {
  height: 56px;
  left: 703px;
  position: absolute;
  top: 0;
  width: 209px;
}

.USP .text-wrapper-106 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 500;
  left: 65px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 11px;
  width: 142px;
}

.USP .group-89 {
  height: 56px;
  left: 457px;
  position: absolute;
  top: 0;
  width: 205px;
}

.USP .text-wrapper-107 {
  color: #043286;
  font-family: 'Poppins', Helvetica;
  font-size: 15px;
  font-weight: 500;
  left: 65px;
  letter-spacing: 0;
  line-height: 17px;
  position: absolute;
  top: 20px;
  white-space: nowrap;
}

.USP .group-90 {
  height: 56px;
  left: 953px;
  position: absolute;
  top: 0;
  width: 191px;
}
</style>
