import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from './App.vue'
import axios from 'axios'
import VueAxios from 'vue-axios'
import './index.css'

import i18n from './i18n'

async function startApp() {
  const app = createApp(App).use(i18n)
  app.use(createPinia())
  axios.defaults.baseURL = 'https://bo.duhanicapital.com/gateway/api/1'
  app.use(VueAxios, axios)
  app.mount('#app')
}

startApp()
