import { createI18n, useI18n } from 'vue-i18n'
import messages from '@intlify/unplugin-vue-i18n/messages'
import { useStorage } from '@vueuse/core'

const messaging: any = messages || {}
/**
 * Load locale messages
 *
 * The loaded `JSON` locale messages is pre-compiled by `@intlify/vue-i18n-loader`, which is integrated into `vue-cli-plugin-i18n`.
 * See: https://github.com/intlify/vue-i18n-loader#rocket-i18n-resource-pre-compilation
 */
function loadLocaleMessages() {
  const locales = import.meta.glob('./locales/*.json')
  for (const path in locales) {
    const matched = path.match(/([A-Za-z0-9-_]+)\./i)
    if (matched && matched.length > 1) {
      const locale = matched[1]
      locales[path]().then((mod: any) => {
        messaging[locale] = mod.default
      })
    }
  }
  return messaging
}

const defaultLocale = useStorage('locale', 'en')

export default createI18n({
  locale: defaultLocale.value,
  fallbackLocale: 'en',
  warnHtmlMessage: false,
  strictMessage: false,
  silentTranslationWarn: true,
  missing: (locale: any, key: any, vm?: any) => {
    const { t, te } = useI18n()
    key = key.includes('.') ? key.split('.').pop() : key
    key = key.toLowerCase().trim()
    return te(key) ? (t(key) as string) : key[0].toUpperCase() + key.slice(1)
  },
  messages: loadLocaleMessages()
})
