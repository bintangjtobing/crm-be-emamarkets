import { fileURLToPath } from 'node:url'

import { ConfigEnv, defineConfig, loadEnv, UserConfig } from 'vite'
import path, { resolve, dirname } from 'path'
import VueI18nPlugin from '@intlify/unplugin-vue-i18n/vite'
import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'
import vueDevTools from 'vite-plugin-vue-devtools'
import basicSsl from '@vitejs/plugin-basic-ssl'

// https://vitejs.dev/config/
export default ({ mode }: ConfigEnv): UserConfig => {
  const root: string = process.cwd()
  const env: any = loadEnv(mode, root)
  console.log(`build mode: ${mode}`, env)
  return defineConfig({
    root,
    base: '/',
    publicDir: 'public',
    plugins: [
      vue(),
      vueJsx(),
      vueDevTools(),
      basicSsl(),
      VueI18nPlugin({
        include: resolve(dirname(fileURLToPath(import.meta.url)), './src/locales/**'),
        fullInstall: false,
        compositionOnly: true
      })
    ],
    server: {
      port: Number(env.VITE_PORT)
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src')
        // '@': fileURLToPath(new URL('./src', import.meta.url))
      }
    },
    esbuild: {},
    build: {
      target: mode === 'development' ? 'modules' : 'es2015',
      sourcemap: mode === 'development'
    }
  })
}
